﻿'****************************************
'         SockT0001 テスト用画面
'            2017-7-23 v3.00
'****************************************
Public Class Form1
    Dim SendRepeatFlag As Boolean
    Dim SendDataCount As Integer
    Dim SendDataSize As Integer
    Dim RecvRepeatFlag As Boolean
    Dim RecvDataCount As Integer
    Dim RecvDataSize As Long

    '***** 文字列を数値に変換(エラー時は0を返す) *****
    Private Function CIntErrZero(ByVal data_str As String) As Integer
        Try
            CIntErrZero = Integer.Parse(data_str)
        Catch ex As Exception
            CIntErrZero = 0
        End Try
    End Function

    Dim i As Integer = 0
    Dim x As Single = 0 '■座標ｘ１初期値 ０
    Dim xx As Single = 0 '■座標ｙ２

    '***** フォームの生成 *****
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1001.MaxLength = 1000000
    End Sub

    '***** ログ表示 *****
    Private Sub AddLog(ByVal log_str As String)
        If (TextBox1001.TextLength >= TextBox1001.MaxLength) Then
            'Dim log_full_str As String = "ログが一杯です。" & Environment.NewLine
            'If (TextBox1001.Text.Substring(TextBox1001.TextLength - log_full_str.Length) <> log_full_str) Then
            '    TextBox1001.AppendText(log_full_str)
            'End If
            'Exit Sub
            TextBox1001.Text = ""
        End If
        TextBox1001.AppendText("[" & String.Format("{0:yyyy/MM/dd hh:mm:ss:ffff}", DateTime.Now) & "]" & log_str & Environment.NewLine)
        TextBox1001.SelectionStart = TextBox1001.TextLength
        TextBox1001.ScrollToCaret()
    End Sub
    Private Sub AddLogWithSender(ByVal sender As Object, ByVal log_str As String)
        AddLog(DirectCast(sender, Control).Name & ":" & log_str)
    End Sub

    '***** ログクリアボタン *****
    Private Sub Button1001_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1001.Click
        TextBox1001.Text = ""
    End Sub

    '***** Listenボタン *****
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        SockT0001Ctrl2.BindIP = TextBox3.Text
        SockT0001Ctrl2.LocalPort = CIntErrZero(TextBox4.Text)
        SockT0001Ctrl2.Listen()
    End Sub

    '***** Connectボタン *****
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        SockT0001Ctrl1.RemoteIP = TextBox1.Text
        SockT0001Ctrl1.RemotePort = CIntErrZero(TextBox2.Text)
        SockT0001Ctrl1.BindIP = TextBox3.Text
        SockT0001Ctrl1.Connect()
    End Sub

    '***** Close(Listen)ボタン *****
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        SockT0001Ctrl2.Close()
    End Sub

    '***** Closeボタン *****
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        SockT0001Ctrl1.Close()
    End Sub

    '***** Sendボタン *****
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim send_data() As Byte
        Dim send_str As String

        send_str = TextBox5.Text
        send_data = System.Text.Encoding.GetEncoding("Shift_JIS").GetBytes(send_str)
        SockT0001Ctrl1.SendData(send_data)
    End Sub

    '***** Open(UDP)ボタン *****
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        SockT0001Ctrl1.RemoteIP = TextBox6.Text
        SockT0001Ctrl1.RemotePort = CIntErrZero(TextBox7.Text)
        SockT0001Ctrl1.BindIP = TextBox8.Text
        SockT0001Ctrl1.Open()
    End Sub

    '***** Bind(UDP)ボタン *****
    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        SockT0001Ctrl1.RemoteIP = TextBox6.Text
        SockT0001Ctrl1.BindIP = TextBox8.Text
        SockT0001Ctrl1.LocalPort = CIntErrZero(TextBox9.Text)
        SockT0001Ctrl1.Bind()
    End Sub

    '***** Close(UDP)ボタン *****
    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        SockT0001Ctrl1.Close()
    End Sub

    '***** SendTo(UDP)ボタン *****
    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Dim send_data() As Byte
        Dim send_str As String

        send_str = TextBox10.Text
        send_data = System.Text.Encoding.GetEncoding("Shift_JIS").GetBytes(send_str)
        SockT0001Ctrl1.SendDataTo(send_data)
    End Sub

    '***** 連続送信ボタン *****
    Private Sub Button10_Click(sender As System.Object, e As System.EventArgs) Handles Button10.Click
        Dim tmp_int As Integer

        If (SendRepeatFlag = False) Then
            SendRepeatFlag = True
            Button10.BackColor = Color.Yellow
            SendDataCount = &H30
            SendDataSize = CIntErrZero(TextBox11.Text)
            If (SendDataSize < 0) Then SendDataSize = 0
            AutoSendData()
            tmp_int = CIntErrZero(TextBox12.Text)
            If (tmp_int < 0) Then tmp_int = 0
            'Timer1.Interval = tmp_int
            'Timer1.Enabled = True
        Else
            SendRepeatFlag = False
            Button10.BackColor = SystemColors.Control
            'Timer1.Enabled = False
        End If
    End Sub

    Private Sub AutoSendData()
        Dim i As Integer
        Dim send_data() As Byte

        ReDim send_data(SendDataSize - 1)
        For i = 0 To SendDataSize - 1
            send_data(i) = SendDataCount
            SendDataCount = SendDataCount + 1
            If (SendDataCount > 255) Then SendDataCount = 0
        Next
        If (RadioButton1.Checked = True) Then
            SockT0001Ctrl1.SendData(send_data)
        Else
            SockT0001Ctrl1.SendDataTo(send_data)
        End If
    End Sub

    '***** 連続受信ボタン *****
    Private Sub Button11_Click(sender As System.Object, e As System.EventArgs) Handles Button11.Click
        If (RecvRepeatFlag = False) Then
            RecvRepeatFlag = True
            RecvDataCount = &H30
            RecvDataSize = 0
            Button11.BackColor = Color.Yellow
        Else
            RecvRepeatFlag = False
            Button11.BackColor = SystemColors.Control
        End If
    End Sub

    '***** 送受信バッファ設定ボタン *****
    Private Sub Button12_Click(sender As System.Object, e As System.EventArgs) Handles Button12.Click
        SockT0001Ctrl1.SendBuffSize = CIntErrZero(TextBox13.Text)
    End Sub
    Private Sub Button13_Click(sender As System.Object, e As System.EventArgs) Handles Button13.Click
        SockT0001Ctrl1.RecvBuffSize = CIntErrZero(TextBox14.Text)
    End Sub

    '***** IPv6モード設定ボタン *****
    Private Sub Button14_Click(sender As System.Object, e As System.EventArgs) Handles Button14.Click
        SockT0001Ctrl1.IPv6Mode = CIntErrZero(TextBox15.Text)
        SockT0001Ctrl2.IPv6Mode = CIntErrZero(TextBox15.Text)
    End Sub

    '***** ソケット通信コントロールのイベント処理 ここから *****

    Private Sub SockT0001Ctrl1_Error(ByVal sender As Object, ByVal err_msg As String) Handles SockT0001Ctrl1.Error
        AddLogWithSender(sender, err_msg)
    End Sub

    Private Sub SockT0001Ctrl2_Error(ByVal sender As Object, ByVal err_msg As String) Handles SockT0001Ctrl2.Error
        AddLogWithSender(sender, err_msg)
    End Sub

    Private Sub SockT0001Ctrl1_StateChanged(ByVal sender As Object) Handles SockT0001Ctrl1.StateChanged
        Select Case SockT0001Ctrl1.State
            Case 0
                Label1.Text = "切断"
                Label1.BackColor = SystemColors.Control
            Case 1
                Label1.Text = "接続待ち"
                Label1.BackColor = Color.Yellow
            Case 2
                Label1.Text = "通信中"
                Label1.BackColor = Color.Blue
        End Select
    End Sub

    Private Sub SockT0001Ctrl2_StateChanged(ByVal sender As Object) Handles SockT0001Ctrl2.StateChanged
        Select Case SockT0001Ctrl2.State
            Case 0
                Label2.Text = "切断"
                Label2.BackColor = SystemColors.Control
            Case 1
                Label2.Text = "接続待ち"
                Label2.BackColor = Color.Yellow
            Case 2
                Label2.Text = "通信中"
                Label2.BackColor = Color.Blue
        End Select
    End Sub

    Private Sub SockT0001Ctrl1_Opened(ByVal sender As Object) Handles SockT0001Ctrl1.Opened
        AddLogWithSender(sender, ":通信開始(UDP)。")
    End Sub

    Private Sub SockT0001Ctrl1_Bound(ByVal sender As Object) Handles SockT0001Ctrl1.Bound
        AddLogWithSender(sender, ":受信開始(UDP)。")
    End Sub

    Private Sub SockT0001Ctrl1_Connecting(ByVal sender As Object) Handles SockT0001Ctrl1.Connecting
        AddLogWithSender(sender, ":接続開始。")
    End Sub

    Private Sub SockT0001Ctrl1_Connected(ByVal sender As Object) Handles SockT0001Ctrl1.Connected
        AddLogWithSender(sender, ":接続しました。" & SockT0001Ctrl1.State)
    End Sub

    Private Sub SockT0001Ctrl1_Closed(ByVal sender As Object, ByVal disc_state As Integer) Handles SockT0001Ctrl1.Closed
        If (disc_state = 0) Then
            AddLogWithSender(sender, ":切断しました。" & SockT0001Ctrl1.State)
        Else
            AddLogWithSender(sender, ":切断されました。" & SockT0001Ctrl1.State)
        End If
    End Sub




    Delegate Sub DisplayTextDelegate(ByVal dat As Short)

    Private Sub DisplayText(ByVal dat As Short)

        'テキストBOXに文字列を追加  
        'Me.TextBox1.Text &= dat & " "

        '描画スタート
        'Static Dim x As Single = 0 '■座標ｘ１初期値 ０
        Static Dim y As Single = 100 '■座標ｙ１初期値 １００（オフセット）
        Static Dim i As Single '■繰り返し計算用
        Static Dim yy As Single '■座標ｘ２
        'Static Dim xx As Single '■座標ｙ２
        'Static Dim xx As Single '■座標ｙ２
        Static Dim g As Graphics = PictureBox1.CreateGraphics '■PictureBox1に書く
        Dim blackPen As New Pen(Color.Black, 1)
        Dim RedPen As New Pen(Color.Red, 2)

        'blackPen.DashStyle = DashStyle.Dot

        g.DrawLine(Pens.Black, 0, 128, 400, 128)
        'For i = 1 To 12
        '    g.DrawLine(blackPen, 0, 128 + i * 10, 400, 128 + i * 10)
        'Next
        'For i = 1 To 12
        '    g.DrawLine(blackPen, 0, 128 - i * 10, 400, 128 - i * 10)
        'Next
        'For i = 1 To 39
        '    g.DrawLine(blackPen, i * 10, 0, i * 10, 256)
        'Next

        'blackPen.Width = 2
        'For i = 1 To 2
        '    g.DrawLine(blackPen, 0, 128 - i * 50, 400, 128 - i * 50)
        '    g.DrawLine(blackPen, 0, 128 + i * 50, 400, 128 + i * 50)
        'Next
        'g.DrawLine(blackPen, 0, 128, 400, 128)
        'For i = 1 To 8
        '    g.DrawLine(blackPen, i * 50, 0, i * 50, 256)
        'Next


        'Dim num As Integer = Integer.Parse(strDisp)

        If (i = 0) Then
            y = -(dat - 128) + 128 '■座標yyの計算（"-"で上下反転，*10で拡大，+100でオフセット）
            'g.DrawLine(Pens.Red, x, y, x, y) '■ライン描画 始点x,y ～ 終点xx,yy
            g.DrawLine(RedPen, x, y, x, y)
            i = i + 1
        Else

            yy = -(dat - 128) + 128 '■座標yyの計算（"-"で上下反転，*10で拡大，+100でオフセット）
            'xx = xx + 10 '■座標xxの計算 （*10で拡大）
            xx = xx + 1 '■座標xxの計算 （*10で拡大）
            'g.DrawLine(Pens.Red, x, y, xx, yy) '■ライン描画 始点x,y ～ 終点xx,yy
            g.DrawLine(RedPen, x, y, xx, yy)
            x = xx '■終点xxを次の始点xとする
            y = yy '■終点yyを次の始点yとする
        End If



    End Sub

    Private Sub DisplayText_init(ByVal dat As Short)

        'テキストBOXに文字列を追加  
        'Me.TextBox1.Text &= dat & " "

        '描画スタート
        'Static Dim x As Single = 0 '■座標ｘ１初期値 ０
        Static Dim y As Single = 100 '■座標ｙ１初期値 １００（オフセット）
        Static Dim i As Single '■繰り返し計算用
        Static Dim yy As Single '■座標ｘ２
        'Static Dim xx As Single '■座標ｙ２
        'Static Dim xx As Single '■座標ｙ２
        Static Dim g As Graphics = PictureBox1.CreateGraphics '■PictureBox1に書く
        Dim blackPen As New Pen(Color.Black, 1)
        Dim RedPen As New Pen(Color.Red, 2)

        'blackPen.DashStyle = DashStyle.Dot

        g.DrawLine(Pens.Black, 0, 128, 400, 128)
        For i = 1 To 12
            g.DrawLine(blackPen, 0, 128 + i * 10, 400, 128 + i * 10)
        Next
        For i = 1 To 12
            g.DrawLine(blackPen, 0, 128 - i * 10, 400, 128 - i * 10)
        Next
        For i = 1 To 39
            g.DrawLine(blackPen, i * 10, 0, i * 10, 256)
        Next

        blackPen.Width = 2
        For i = 1 To 2
            g.DrawLine(blackPen, 0, 128 - i * 50, 400, 128 - i * 50)
            g.DrawLine(blackPen, 0, 128 + i * 50, 400, 128 + i * 50)
        Next
        g.DrawLine(blackPen, 0, 128, 400, 128)
        For i = 1 To 8
            g.DrawLine(blackPen, i * 50, 0, i * 50, 256)
        Next


        'Dim num As Integer = Integer.Parse(strDisp)

        'If (i = 0) Then
        '    y = -(dat - 128) + 128 '■座標yyの計算（"-"で上下反転，*10で拡大，+100でオフセット）
        '    'g.DrawLine(Pens.Red, x, y, x, y) '■ライン描画 始点x,y ～ 終点xx,yy
        '    g.DrawLine(RedPen, x, y, x, y)
        '    i = i + 1
        'Else

        '    yy = -(dat - 128) + 128 '■座標yyの計算（"-"で上下反転，*10で拡大，+100でオフセット）
        '    'xx = xx + 10 '■座標xxの計算 （*10で拡大）
        '    xx = xx + 1 '■座標xxの計算 （*10で拡大）
        '    'g.DrawLine(Pens.Red, x, y, xx, yy) '■ライン描画 始点x,y ～ 終点xx,yy
        '    g.DrawLine(RedPen, x, y, xx, yy)
        '    x = xx '■終点xxを次の始点xとする
        '    y = yy '■終点yyを次の始点yとする
        'End If



    End Sub

    Private Sub SockT0001Ctrl1_DataArrival(ByVal sender As Object, ByVal recv_data() As Byte, ByVal recv_bytes As Integer) Handles SockT0001Ctrl1.DataArrival
        Dim i As Integer
        Dim recv_str As String
        Dim disp_recv_str As String

        '***** 連続受信ONのとき *****
        If (RecvRepeatFlag = True) Then
            For i = 0 To recv_bytes - 1
                If (recv_data(i) = RecvDataCount) Then
                    RecvDataCount = RecvDataCount + 1
                    If (RecvDataCount > 255) Then RecvDataCount = 0
                    If (RecvDataSize < Long.MaxValue) Then
                        RecvDataSize = RecvDataSize + 1
                    End If
                Else
                    AddLogWithSender(sender, ":受信予定データ=" & RecvDataCount & ":受信データ=" & recv_data(i) & ":ここまでの正常受信バイト数=" & RecvDataSize)
                    RecvDataCount = recv_data(i) + 1
                    If (RecvDataCount > 255) Then RecvDataCount = 0
                    RecvDataSize = 0
                End If
            Next
            Exit Sub
        End If

        '***** バイナリ受信表示のチェック *****
        If (CheckBox1.Checked = False) Then
            recv_str = System.Text.Encoding.GetEncoding("Shift_JIS").GetString(recv_data)
        Else
            recv_str = BitConverter.ToString(recv_data)
        End If

        'For i = 0 To 23
        '    disp_recv_str(i) = recv_str(i)
        'Next
        disp_recv_str = recv_str.Substring(0, 47)

        'AddLogWithSender(sender, ":受信完了:" & recv_bytes & ":" & recv_str)  '全データ表示なので、PICは2秒毎に。12kのデータ解析用。
        AddLogWithSender(sender, ":受信完了:" & recv_bytes & ":" & disp_recv_str)  '先頭(0～5)を2回分表示。

        Dim dlg As New DisplayTextDelegate(AddressOf DisplayText)
        Dim dat As Short
        dat = 20
        Me.Invoke(dlg, New Object() {dat})

    End Sub

    Private Sub SockT0001Ctrl1_SendProgress(ByVal sender As Object, ByVal send_bytes As Integer) Handles SockT0001Ctrl1.SendProgress
        '***** 連続送信ONのとき *****
        If (SendRepeatFlag = True) Then
            Exit Sub
        End If

        AddLogWithSender(sender, ":送信中:" & send_bytes)
    End Sub

    Private Sub SockT0001Ctrl1_SendComplete(ByVal sender As Object, ByVal send_bytes As Integer) Handles SockT0001Ctrl1.SendComplete
        '***** 連続送信ONのとき *****
        If (SendRepeatFlag = True) Then
            Exit Sub
        End If

        AddLogWithSender(sender, ":送信完了:" & send_bytes)
    End Sub

    Private Sub SockT0001Ctrl2_Listening(ByVal sender As Object) Handles SockT0001Ctrl2.Listening
        AddLogWithSender(sender, ":待ち受け開始。")
    End Sub

    Private Sub SockT0001Ctrl2_ConnectionRequest(ByVal sender As Object, ByVal comm_socket As System.Net.Sockets.Socket) Handles SockT0001Ctrl2.ConnectionRequest
        AddLogWithSender(sender, ":接続要求受付。")
        AddLog("RemotIP=" & SockT0001Ctrl2.RemoteIP)
        AddLog("RemotPort=" & SockT0001Ctrl2.RemotePort)
        SockT0001Ctrl1.Accept(comm_socket)
    End Sub

    Private Sub SockT0001Ctrl2_Closed(ByVal sender As Object, ByVal disc_state As Integer) Handles SockT0001Ctrl2.Closed
        If (disc_state = 0) Then
            AddLogWithSender(sender, ":切断しました。")
        Else
            AddLogWithSender(sender, ":切断されました。")
        End If
    End Sub

    Private Sub SockT0001Ctrl1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SockT0001Ctrl1.Load

    End Sub

    Private Sub SockT0001Ctrl2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SockT0001Ctrl2.Load

    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        Refresh()
        x = 0 : xx = 0
        i = 0

        Dim dlg As New DisplayTextDelegate(AddressOf DisplayText_init)

        Dim dat As Short

        dat = 20
        'MsgBox(dat)
        ''Invoke(New Delegate_RcvDataToTextBox(AddressOf Me.RcvDataToTextBox), args)
        Me.Invoke(dlg, New Object() {dat})
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click

    End Sub
End Class
